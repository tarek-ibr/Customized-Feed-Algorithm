#include "user.h"
#include "ui_user.h"

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);
    setFixedSize(width(), height());
}

Dialog::~Dialog()
{
    delete ui;
}
